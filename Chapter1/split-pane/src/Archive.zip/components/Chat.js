function Chat() {
    return <div className="Chat" />;
}

export default Chat;