function Contacts() {
    return <div className="Contacts" />;
}

export default Contacts;